public abstract class Clientes {
    private String nombre;

    public Clientes(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void mostrarDatos(String tipoCliente , String nombreCliente) {
        System.out.println("Facturando a " +tipoCliente);
        System.out.println("Enviando correo a" + nombreCliente);
    }

    public abstract double calcularFactura(double total , double impuestos);


    class ClienteEstandar extends Clientes {
        public ClienteEstandar(String nombre) {
            super(nombre);
        }

        @Override
        public double calcularFactura(double total, double impuestos) {
            mostrarDatos("Estandar" , nombre);
            return (total + (total * impuestos));
        }
    }
}
