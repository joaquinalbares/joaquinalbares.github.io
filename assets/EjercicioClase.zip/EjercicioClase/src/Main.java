import java.util.ArrayList;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {

    public static void main(String[] args) {
        System.out.println("Factura");
        int producto1 = CalculaTotal(1 , 20 , 1);
        int producto2 = CalculaTotal(5 , 10 , 2);
        CalculaDescuento(producto1 , producto2);
    }

    public static int CalculaTotal(int cantidad, int precio, int orden) {
        System.out.println("Cantidad " + orden + ": "  + cantidad);
        System.out.println("Precio " + orden + ": "  + precio);
        System.out.println("Total " + orden + ": "  + cantidad*precio);
        return cantidad*precio;
    }

    public static void CalculaDescuento(int productoA, int productoB) {
        if (productoA*productoB>100) {
            System.out.println("Descuento aplicado");
        }
    }
}