/**
 * La clase Rectangulo representa un rectángulo definido por dos lados.
 */
public class Rectangulo {
    private final int lado1, lado2;

    /**
     *
     * @param lado1
     * @param lado2
     */
    public Rectangulo(int lado1, int lado2) {
        this.lado1 = lado1;
        this.lado2 = lado2;
    }


    /**
     * @return lado1
     */
    public int getLado1() {
        return lado1;
    }

    /**
     * @return lado2
     */
    public int getLado2() {
        return lado2;
    }

    /**
     * @return El area del rectangulo
     */
    private double calcularArea() {
        return lado1 * lado2;
    }

    /**
     * Calcula el perímetro del rectángulo basado en la suma de sus dos lados multiplicada por 2.
     *
     * @return El perímetro del rectángulo.
     */
    private double calcularPerimetro() {
        return 2*(lado1 + lado2);
    }

    /**
     * Muestra por pantalla el area y el perimetro del rectangulo
     */
    public void dibujarRectangulo() {
        System.out.println("Área: " + calcularArea());
        System.out.println("Perímetro: " + calcularPerimetro());
    }
}
